#include "runtime.hpp"

int main()
{
	runtime program;
	program.start();
}
